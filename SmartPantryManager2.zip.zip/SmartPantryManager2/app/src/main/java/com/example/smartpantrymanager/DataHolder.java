package com.example.smartpantrymanager;

import java.util.ArrayList;

public class DataHolder {

    public static ArrayList<String> ingredients = new ArrayList<>();

}