package com.example.smartpantrymanager;

import android.content.Intent;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    ListView listIngredients;
    Button btnAddIngredient;
    Button btnRecipes;
    Button btnSettings;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        listIngredients = findViewById(R.id.listIngredients);
        btnAddIngredient = findViewById(R.id.btnAddIngredient);
        btnRecipes = findViewById(R.id.btnRecipes);
        btnSettings = findViewById(R.id.btnSettings);

        if (DataHolder.ingredients.isEmpty()) {
            DataHolder.ingredients.add("Tomatoes");
            DataHolder.ingredients.add("Eggs");
            DataHolder.ingredients.add("Milk");
            DataHolder.ingredients.add("Bread");
        }

        loadIngredients();

        listIngredients.setOnItemLongClickListener((parent, view, position, id) -> {
            DataHolder.ingredients.remove(position);
            loadIngredients();
            return true;
        });

        btnAddIngredient.setOnClickListener(v -> {
            Intent intent = new Intent(
                    MainActivity.this,
                    AddIngredientActivity.class);
            startActivity(intent);
        });

        btnRecipes.setOnClickListener(v -> {
            Intent intent = new Intent(
                    MainActivity.this,
                    SuggestedRecipesActivity.class);
            startActivity(intent);
        });

        btnSettings.setOnClickListener(v -> {
            Intent intent = new Intent(
                    MainActivity.this,
                    SettingsActivity.class);
            startActivity(intent);
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        loadIngredients();
    }

    private void loadIngredients() {
        ArrayAdapter<String> adapter = new ArrayAdapter<>(
                this,
                android.R.layout.simple_list_item_1,
                DataHolder.ingredients);

        listIngredients.setAdapter(adapter);
    }
}