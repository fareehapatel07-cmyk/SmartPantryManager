package com.example.smartpantrymanager;

import android.content.Intent;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import androidx.appcompat.app.AppCompatActivity;

public class SuggestedRecipesActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_suggested_recipes);

        ListView listRecipes = findViewById(R.id.listRecipes);

        String[] recipes = {
                "Omelette",
                "French Toast",
                "Grilled Cheese",
                "Tomato Soup",
                "Egg Sandwich"
        };

        ArrayAdapter<String> adapter =
                new ArrayAdapter<>(this,
                        android.R.layout.simple_list_item_1,
                        recipes);

        listRecipes.setAdapter(adapter);

        listRecipes.setOnItemClickListener((parent, view, position, id) -> {
            Intent intent = new Intent(
                    SuggestedRecipesActivity.this,
                    RecipeDetailActivity.class);
            startActivity(intent);
        });
    }
}