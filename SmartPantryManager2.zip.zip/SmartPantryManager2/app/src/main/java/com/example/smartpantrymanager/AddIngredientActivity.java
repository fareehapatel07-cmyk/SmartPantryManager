package com.example.smartpantrymanager;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;

import androidx.appcompat.app.AppCompatActivity;

public class AddIngredientActivity extends AppCompatActivity {

    EditText etIngredientName;
    Button btnSave;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_ingredient);

        etIngredientName = findViewById(R.id.etIngredientName);
        btnSave = findViewById(R.id.btnSave);

        btnSave.setOnClickListener(v -> {

            String ingredient =
                    etIngredientName.getText().toString();

            if (!ingredient.isEmpty()) {
                DataHolder.ingredients.add(ingredient);
                finish();
            }
        });
    }
}